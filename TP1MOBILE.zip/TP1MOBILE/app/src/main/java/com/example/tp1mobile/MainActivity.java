package com.example.tp1mobile;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recycle;
    private HashMap<String, Animal> list;
    private AnimalAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycle = (RecyclerView) findViewById(R.id.liste);
        list = AnimalList.hashMap;
        adapter = new AnimalAdapter(list);

        recycle.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recycle.setAdapter(adapter);


        /*ArrayAdapter<String> items = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, AnimalList.getNameArray());
        final ListView listView = (ListView) findViewById(R.id.liste);
        listView.setAdapter(items);

        listView.setClickable(true);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String names = listView.getItemAtPosition(position).toString();
                Intent inte = new Intent(MainActivity.this, AnimalActivity.class);
                inte.putExtra("nom", names);
                startActivity(inte);
            }
        });

         */

    }
}