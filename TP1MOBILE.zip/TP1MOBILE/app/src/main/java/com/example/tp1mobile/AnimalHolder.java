package com.example.tp1mobile;


import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class AnimalHolder extends RecyclerView.ViewHolder {

    private ImageView logo;
    private TextView animals;

    public AnimalHolder(View itemView) {
        super(itemView);

        animals = (TextView) itemView.findViewById(R.id.anim);
    }

    void display(Animal animalis) {
        animals.setText(animalis.toString());
    }
}
