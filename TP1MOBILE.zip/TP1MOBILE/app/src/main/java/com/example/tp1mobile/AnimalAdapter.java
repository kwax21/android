package com.example.tp1mobile;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.HashMap;

public class AnimalAdapter extends RecyclerView.Adapter<AnimalHolder> {

    HashMap<String, Animal> lists;

    AnimalAdapter(HashMap<String, Animal> list){
        this.lists = list;
    }
    @Override
    public AnimalHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.activity_recycler, parent, false);
        return new AnimalHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AnimalHolder animalHolder, int position) {
        animalHolder.display(lists.get(position));
    }


    @Override
    public int getItemCount() {
        return lists.size();
    }
}
