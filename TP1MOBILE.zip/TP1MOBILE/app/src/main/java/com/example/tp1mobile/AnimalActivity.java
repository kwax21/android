package com.example.tp1mobile;

import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class AnimalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.animal_char);

        final TextView nom = (TextView) findViewById(R.id.name);
        final ImageView text = (ImageView) findViewById(R.id.img);
        final TextView esp = (TextView) findViewById(R.id.esp);
        final TextView gest = (TextView) findViewById(R.id.gest);
        final TextView poids = (TextView) findViewById(R.id.poids1);
        final TextView poidss = (TextView) findViewById(R.id.poids2);
        final TextInputLayout text = (TextInputLayout) findViewById(R.id.texte);



    }
}
