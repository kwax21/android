package com.example.tp1mobile;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import static com.example.tp1mobile.AnimalList.getAnimal;

public class AnimalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.animal_char);

        Bundle extras = getIntent().getExtras();
        final String data = extras.getString("nom");


        final TextView nom = (TextView) findViewById(R.id.name);
        final ImageView imge = (ImageView) findViewById(R.id.img);
        final TextView esp = (TextView) findViewById(R.id.esp);
        final TextView gest = (TextView) findViewById(R.id.gest);
        final TextView poids = (TextView) findViewById(R.id.poids1);
        final TextView poidss = (TextView) findViewById(R.id.poids2);
        final EditText inpute = (EditText) findViewById(R.id.input);

        final Button bouton = (Button) findViewById(R.id.but);

        nom.setText(data);
        imge.setImageResource(getAnimal(data).getImgFile());
        esp.setText(getAnimal(data).getStrHightestLifespan());
        gest.setText(getAnimal(data).getStrGestationPeriod());
        poids.setText(getAnimal(data).getStrBirthWeight());
        poidss.setText(getAnimal(data).getStrAdultWeight());
        inpute.setText(getAnimal(data).getConservationStatus());

        bouton.setClickable(true);
        bouton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String cons = inpute.getText().toString();
                getAnimal(data).setConservationStatus(cons);
            }
        });


    }
}
